// Simple authentication context and utilities
export interface User {
  id: string
  name: string
  email: string
  type: "student" | "staff" | "admin"
  rollNumber?: string // For students
  department?: string
  year?: number // For students
  subjects?: string[] // For staff
}

// Mock user data for demonstration
export const mockUsers: Record<string, User> = {
  STU001: {
    id: "STU001",
    name: "K SAITEJA",
    email: "k.saiteja@student.hindustanuniv.ac.in",
    type: "student",
    rollNumber: "STU001",
    department: "Computer Science",
    year: 3,
  },
  STU002: {
    id: "STU002",
    name: "Priya Sharma",
    email: "priya.sharma@student.hindustanuniv.ac.in",
    type: "student",
    rollNumber: "STU002",
    department: "Information Technology",
    year: 2,
  },
  STAFF001: {
    id: "STAFF001",
    name: "K Swarnalakshmi",
    email: "k.swarnalakshmi@hindustanuniv.ac.in",
    type: "staff",
    department: "Computer Science",
    subjects: ["Data Structures", "Algorithms", "Database Management"],
  },
  STAFF002: {
    id: "STAFF002",
    name: "Prof. Rajesh Singh",
    email: "rajesh.singh@hindustanuniv.ac.in",
    type: "staff",
    department: "Information Technology",
    subjects: ["Web Development", "Software Engineering", "Mobile App Development"],
  },
  ADMIN001: {
    id: "ADMIN001",
    name: "Dr. Suresh Patel",
    email: "suresh.patel@hindustanuniv.ac.in",
    type: "admin",
    department: "Administration",
  },
}

export function authenticateUser(userId: string, password: string): User | null {
  // Simple authentication - in real app, this would be secure
  const user = mockUsers[userId]

  if (user) {
    if (userId === "STU001" && password === "saiteja12") {
      return user
    } else if (userId === "STAFF001" && password === "rakesh12") {
      return user
    } else if (userId === "ADMIN001" && password === "lathif12") {
      return user
    } else if (password === "password123") {
      return user
    }
  }
  return null
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null

  const userData = localStorage.getItem("currentUser")
  return userData ? JSON.parse(userData) : null
}

export function setCurrentUser(user: User): void {
  if (typeof window === "undefined") return

  localStorage.setItem("currentUser", JSON.stringify(user))
}

export function logout(): void {
  if (typeof window === "undefined") return

  localStorage.removeItem("currentUser")
}
