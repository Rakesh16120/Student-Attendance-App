export interface StudentRecord {
  rollNo: string
  name: string
  class: string
  gpa: number
  subjects: string[]
  marks: Record<string, number[]>
  attendance: number
  participation: string[]
  sports: string[]
  awards: string[]
}

// Complete list of 241 students (3rd Year) with realistic data
export const STUDENT_DATA: StudentRecord[] = [
  // Updated first 5 students as requested
  { rollNo: "23112429", name: "KATTA SAITEJA", class: "3rd Year - A", gpa: 8.45, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [88, 90, 92, 89], "Sem 6": [90, 92, 94, 91] }, attendance: 94, participation: ["Tech Fest", "Hackathon"], sports: ["Cricket"], awards: ["Academic Excellence"] },
  { rollNo: "23112359", name: "R RAKESH", class: "3rd Year - B", gpa: 7.82, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [78, 82, 85, 80], "Sem 6": [80, 84, 87, 82] }, attendance: 87, participation: ["Coding Competition"], sports: ["Badminton"], awards: ["Good Performance"] },
  { rollNo: "23112418", name: "SK ABDUL LATHIF", class: "3rd Year - A", gpa: 9.15, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [92, 94, 96, 93], "Sem 6": [94, 96, 98, 95] }, attendance: 96, participation: ["Tech Fest", "Debate"], sports: ["Football"], awards: ["Merit Award", "Topper"] },
  { rollNo: "23112368", name: "S LOHITH", class: "3rd Year - B", gpa: 8.67, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [86, 88, 90, 87], "Sem 6": [88, 90, 92, 89] }, attendance: 92, participation: ["Hackathon"], sports: ["Volleyball"], awards: ["Best Project"] },
  { rollNo: "23112417", name: "SK SALEEM", class: "3rd Year - A", gpa: 7.58, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [76, 79, 83, 80], "Sem 6": [78, 81, 85, 82] }, attendance: 85, participation: ["Sports Day"], sports: ["Cricket"], awards: [] },

  // Additional students from the provided image (changed to 3rd Year with new CGPA)
  { rollNo: "23112353", name: "KAMASALA ABHILASH", class: "3rd Year - A", gpa: 8.25, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [82, 85, 88, 84], "Sem 6": [85, 87, 90, 86] }, attendance: 92, participation: ["Tech Fest", "Hackathon"], sports: ["Cricket"], awards: ["Good Performance"] },
  { rollNo: "23112357", name: "DHARUN KUMAR K", class: "3rd Year - A", gpa: 7.98, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [78, 82, 85, 80], "Sem 6": [81, 84, 87, 83] }, attendance: 88, participation: ["Coding Competition"], sports: ["Badminton"], awards: [] },
  { rollNo: "23112364", name: "SRIRAMA CHANDRA SAI", class: "3rd Year - A", gpa: 8.52, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [86, 88, 90, 87], "Sem 6": [88, 90, 92, 89] }, attendance: 95, participation: ["Tech Fest", "Debate"], sports: ["Football"], awards: ["Merit Award"] },
  { rollNo: "23112371", name: "MADHAVA PRASHANTH M", class: "3rd Year - B", gpa: 8.12, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [80, 83, 86, 82], "Sem 6": [83, 85, 88, 84] }, attendance: 90, participation: ["Tech Fest"], sports: ["Football"], awards: [] },
  { rollNo: "23112372", name: "SANJIV RAJ S", class: "3rd Year - B", gpa: 7.35, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [72, 75, 79, 76], "Sem 6": [75, 78, 82, 79] }, attendance: 82, participation: [], sports: ["Cricket"], awards: [] },
  { rollNo: "23112374", name: "KANKANALA JASWANTH", class: "3rd Year - A", gpa: 8.88, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [87, 89, 91, 88], "Sem 6": [89, 91, 93, 90] }, attendance: 96, participation: ["Hackathon", "Tech Fest"], sports: ["Badminton"], awards: ["Best Coder"] },
  { rollNo: "23112380", name: "PUVVADA SAI SANDEEP P", class: "3rd Year - B", gpa: 7.92, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [76, 80, 83, 79], "Sem 6": [79, 82, 85, 81] }, attendance: 87, participation: ["Tech Fest"], sports: ["Football"], awards: [] },
  { rollNo: "23112381", name: "SHARMILA S", class: "3rd Year - A", gpa: 8.39, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [83, 85, 88, 85], "Sem 6": [85, 87, 90, 87] }, attendance: 93, participation: ["Cultural Night", "Debate"], sports: ["Volleyball"], awards: ["Good Participation"] },
  { rollNo: "23112384", name: "THIPPANABHOYINA VENKATA NAGA H", class: "3rd Year - B", gpa: 7.61, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [74, 77, 81, 78], "Sem 6": [77, 80, 83, 81] }, attendance: 86, participation: ["Sports Day"], sports: ["Cricket"], awards: [] },
  { rollNo: "23112385", name: "S MERVINDHONI", class: "3rd Year - A", gpa: 8.65, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [84, 87, 89, 86], "Sem 6": [86, 89, 91, 88] }, attendance: 94, participation: ["Tech Fest", "Hackathon"], sports: ["Badminton"], awards: ["Merit Award"] },
  { rollNo: "23112386", name: "DINESH M", class: "3rd Year - B", gpa: 7.48, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [73, 76, 80, 77], "Sem 6": [76, 79, 82, 80] }, attendance: 84, participation: [], sports: ["Football"], awards: [] },
  { rollNo: "23112388", name: "THRASHMIN M", class: "3rd Year - A", gpa: 8.09, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [79, 82, 85, 82], "Sem 6": [82, 84, 87, 85] }, attendance: 89, participation: ["Coding Competition"], sports: [], awards: [] },
  { rollNo: "23112390", name: "KETHAN REDDY ODURU", class: "3rd Year - B", gpa: 7.78, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [76, 79, 83, 80], "Sem 6": [79, 82, 85, 83] }, attendance: 88, participation: ["Sports Day"], sports: ["Badminton"], awards: [] },
  { rollNo: "23112392", name: "S. MEDBIN ENIGO S", class: "3rd Year - A", gpa: 8.34, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [81, 84, 87, 84], "Sem 6": [84, 86, 89, 86] }, attendance: 91, participation: ["Tech Fest"], sports: ["Cricket"], awards: [] },
  { rollNo: "23112397", name: "SHAIK ABDUL NOOR AHMED", class: "3rd Year - B", gpa: 8.05, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [77, 81, 84, 81], "Sem 6": [80, 83, 86, 84] }, attendance: 89, participation: ["Debate"], sports: ["Football"], awards: [] },
  { rollNo: "23112400", name: "VIJAY SURYA M", class: "3rd Year - A", gpa: 7.42, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [74, 77, 81, 78], "Sem 6": [77, 80, 83, 81] }, attendance: 85, participation: [], sports: ["Cricket"], awards: [] },
  { rollNo: "23112401", name: "BALAKUMARAN U V", class: "3rd Year - B", gpa: 8.27, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [82, 85, 88, 85], "Sem 6": [85, 87, 90, 87] }, attendance: 92, participation: ["Hackathon"], sports: ["Badminton"], awards: ["Good Performer"] },
  { rollNo: "23112403", name: "MAHESHWARAN M C", class: "3rd Year - A", gpa: 7.93, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [77, 80, 84, 81], "Sem 6": [80, 83, 86, 84] }, attendance: 87, participation: ["Tech Fest"], sports: [], awards: [] },
  { rollNo: "23112407", name: "GANDLA JYOSTHNA", class: "3rd Year - B", gpa: 8.99, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [88, 90, 92, 89], "Sem 6": [90, 92, 94, 91] }, attendance: 97, participation: ["Tech Fest", "Cultural Night"], sports: ["Volleyball"], awards: ["Academic Excellence"] },
  { rollNo: "23112408", name: "PRAVEEN S", class: "3rd Year - A", gpa: 7.66, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [75, 78, 82, 79], "Sem 6": [78, 81, 84, 82] }, attendance: 86, participation: ["Sports Day"], sports: ["Football"], awards: [] },
  { rollNo: "23112409", name: "ASHUTOSH S SAHANI", class: "3rd Year - B", gpa: 8.21, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [80, 83, 86, 83], "Sem 6": [83, 85, 88, 86] }, attendance: 90, participation: ["Coding Competition"], sports: ["Cricket"], awards: [] },
  { rollNo: "23112411", name: "KONDAREDDY THANUJA REDDY", class: "3rd Year - A", gpa: 8.54, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [84, 86, 89, 86], "Sem 6": [86, 88, 91, 88] }, attendance: 94, participation: ["Tech Fest", "Hackathon"], sports: ["Badminton"], awards: ["Merit Award"] },
  { rollNo: "23112412", name: "RAJULAGARI KUSHALINI", class: "3rd Year - B", gpa: 7.37, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [73, 76, 80, 77], "Sem 6": [76, 79, 82, 80] }, attendance: 84, participation: [], sports: ["Volleyball"], awards: [] },
  { rollNo: "23112413", name: "TANUJAA MAGESH", class: "3rd Year - A", gpa: 8.07, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [78, 81, 85, 82], "Sem 6": [81, 83, 87, 85] }, attendance: 88, participation: ["Tech Fest"], sports: [], awards: [] },
  { rollNo: "23112414", name: "VEERADARSHAN P", class: "3rd Year - B", gpa: 7.79, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [76, 79, 83, 80], "Sem 6": [79, 82, 85, 83] }, attendance: 87, participation: ["Debate"], sports: ["Cricket"], awards: [] },
  { rollNo: "23112416", name: "SWETHA P", class: "3rd Year - A", gpa: 8.38, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [82, 85, 88, 85], "Sem 6": [85, 87, 90, 87] }, attendance: 92, participation: ["Cultural Night"], sports: ["Badminton"], awards: ["Good Participant"] },
  { rollNo: "23112424", name: "MARIA BENEDICT TONY ANTONYSAM", class: "3rd Year - A", gpa: 8.76, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [85, 87, 90, 87], "Sem 6": [87, 89, 92, 89] }, attendance: 95, participation: ["Hackathon", "Tech Fest"], sports: ["Volleyball"], awards: ["Best Student"] },
  { rollNo: "23112425", name: "SATHISH K", class: "3rd Year - B", gpa: 7.81, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [77, 80, 84, 81], "Sem 6": [80, 83, 86, 84] }, attendance: 88, participation: ["Tech Fest"], sports: ["Cricket"], awards: [] },
  { rollNo: "23112427", name: "VIGNESH C", class: "3rd Year - A", gpa: 8.10, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [79, 82, 85, 82], "Sem 6": [82, 84, 87, 85] }, attendance: 89, participation: ["Coding Competition"], sports: ["Badminton"], awards: [] },
  { rollNo: "23112432", name: "AKATHEES KUMAR R", class: "3rd Year - B", gpa: 7.53, subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"], marks: { "Sem 5": [74, 77, 81, 78], "Sem 6": [77, 80, 83, 81] }, attendance: 86, participation: ["Sports Day"], sports: ["Football"], awards: [] },

  // Additional students to reach 241 total (3rd Year only)
  ...Array.from({ length: 209 }, (_, i) => {
    const gpa = 7.0 + Math.random() * 3.0; // CGPA between 7.0 and 10.0
    const attendance = 80 + Math.floor(Math.random() * 18); // Attendance between 80% and 98%
    return {
      rollNo: String(23112433 + i),
      name: `STUDENT ${String(i + 33).padStart(3, "0")}`,
      class: ["3rd Year - A", "3rd Year - B"][i % 2],
      gpa: parseFloat(gpa.toFixed(2)),
      subjects: ["Advanced DSA", "Cloud Computing", "AI/ML", "System Design"],
      marks: {
        "Sem 5": [70 + Math.floor(Math.random() * 25), 72 + Math.floor(Math.random() * 25), 75 + Math.floor(Math.random() * 20), 73 + Math.floor(Math.random() * 22)],
        "Sem 6": [72 + Math.floor(Math.random() * 25), 74 + Math.floor(Math.random() * 25), 77 + Math.floor(Math.random() * 20), 75 + Math.floor(Math.random() * 22)],
      },
      attendance: attendance,
      participation: [
        ["Tech Fest", "Hackathon", "Coding Competition", "Debate"],
        ["Sports Day", "Cultural Night"],
        [],
      ][Math.floor(Math.random() * 3)],
      sports: [
        ["Cricket", "Football", "Badminton", "Volleyball"],
        ["Badminton", "Cricket"],
        [],
      ][Math.floor(Math.random() * 3)],
      awards: Math.random() > 0.8 ? ["Merit Award", "Good Performance", "Best Participant"][Math.floor(Math.random() * 3)] : [],
    }
  }),
]
