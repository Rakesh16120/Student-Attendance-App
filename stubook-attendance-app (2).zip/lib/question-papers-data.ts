export interface Question {
  question: string
  marks: number
  co: string
  btl?: string
  isImportant?: boolean
}

export interface QuestionPart {
  totalMarks: number
  questions: Question[]
}

export interface QuestionPaper {
  id: string
  courseCode: string
  courseName: string
  department: string
  semester: string
  examDate: string
  maxMarks: number
  duration: string
  partA: QuestionPart
  partB: QuestionPart
  partC?: QuestionPart
  importantQuestions: string[]
}

export const IMPORTANT_QUESTIONS_BY_COURSE: Record<string, string[]> = {
  "ECT51001": [
    "Define unit cell with examples",
    "CVD and PVD techniques for material deposition",
    "Phase diagrams and their applications",
    "Polymer structure and properties relationship",
    "Classification and properties of engineering materials"
  ],
  "EMA51001": [
    "Eigen values and Eigen vectors of matrices",
    "Partial derivatives and chain rule",
    "Double and triple integrals",
    "Differential equations using Laplace transform",
    "Series convergence tests",
    "Gamma and Beta functions"
  ],
  "ELS51001": [
    "Tense forms and their applications",
    "Types of sentences",
    "Modal verbs and their usage",
    "Parts of speech and their functions",
    "Formal letter writing",
    "Paragraph development and cohesion",
    "Error identification and correction"
  ],
  "EPH51001": [
    "Hooke's law and elasticity",
    "Ultrasonic waves and applications",
    "Crystal structures and unit cells",
    "Blackbody radiation and Planck's law",
    "Quantum mechanics fundamentals",
    "Semiconductor properties",
    "Laser principles and applications"
  ],
  "ECS51001": [
    "Algorithm design and flowchart creation",
    "Data types and operators in C",
    "Control structures: loops and conditionals",
    "Functions and recursion",
    "Arrays and strings in C",
    "Pointers and memory management",
    "Structures and unions",
    "File handling in C"
  ]
}

export const QUESTION_PAPERS: QuestionPaper[] = [
  {
    id: "ect51001",
    courseCode: "ECT51001",
    courseName: "Engineering Materials",
    department: "Chemistry/Materials",
    semester: "5",
    examDate: "November 2022",
    maxMarks: 100,
    duration: "3 hours",
    partA: {
      totalMarks: 20,
      questions: [
        { question: "Define unit cell.", marks: 2, co: "1", btl: "BTL 2", isImportant: true },
        { question: "Find the number of components in the decomposition of CaCO3.", marks: 2, co: "1", btl: "BTL 3" },
        { question: "Give the properties of norbide.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "What do you mean by oil dag and aqua dag?", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Differentiate top-down and bottom-up approach.", marks: 2, co: "3", btl: "BTL 2", isImportant: true },
        { question: "Write the advantages of CVD technique.", marks: 2, co: "3", btl: "BTL 2" },
        { question: "Polyvinyl chloride has higher Tg than polyethylene - Justify.", marks: 3, co: "4", btl: "BTL 3", isImportant: true },
        { question: "Comment on degree of polymerisation.", marks: 2, co: "4", btl: "BTL 2" },
        { question: "How does a liquid crystal differ from that of a solid and an isotropic liquid?", marks: 2, co: "5", btl: "BTL 2" },
        { question: "Write the factors that affect the conductivity of polymers.", marks: 2, co: "5", btl: "BTL 2" }
      ]
    },
    partB: {
      totalMarks: 30,
      questions: [
        { question: "Explain the principle and applications of XRD.", marks: 6, co: "1", btl: "BTL 3", isImportant: true },
        { question: "Describe the application of the reduced phase rule to a Pb-Sn system.", marks: 6, co: "1", btl: "BTL 3" },
        { question: "Discuss the preparation and properties of bhenformaldehyde resin.", marks: 6, co: "2", btl: "BTL 2" },
        { question: "Explain various phases and transformations involved in the water system.", marks: 6, co: "3", btl: "BTL 3", isImportant: true },
        { question: "Discuss the preparation, properties and uses of phenol-formaldehyde resin.", marks: 6, co: "4", btl: "BTL 3", isImportant: true }
      ]
    },
    importantQuestions: [
      "Define unit cell with examples",
      "CVD and PVD techniques for material deposition",
      "Phase diagrams and their applications",
      "Polymer structure and properties relationship",
      "Classification and properties of engineering materials"
    ]
  },
  {
    id: "ema51001",
    courseCode: "EMA51001",
    courseName: "Matrices and Calculus",
    department: "Mathematics",
    semester: "5",
    examDate: "November 2022",
    maxMarks: 100,
    duration: "3 hours",
    partA: {
      totalMarks: 20,
      questions: [
        { question: "State Cayley Hamilton theorem.", marks: 2, co: "1", btl: "BTL 1" },
        { question: "Find the sum and product of the Eigen values of the matrix A = [[1,2,3],[-1,2,1],[1,1,1]].", marks: 2, co: "1", btl: "BTL 2", isImportant: true },
        { question: "Find dy/dx, if √x + √y = √a.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Evaluate ∫sin²x cos x dx.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Change the order of integration for the double integral ∫∫f(x,y)dxdy.", marks: 2, co: "3", btl: "BTL 2", isImportant: true },
        { question: "Evaluate ∫∫r²dr dθ.", marks: 2, co: "3", btl: "BTL 2" },
        { question: "Find the complementary function of (D² + 2D + 4)y = 0.", marks: 2, co: "4", btl: "BTL 2" },
        { question: "Find the particular integral of (D² + 2D + 1)y = sin x.", marks: 2, co: "4", btl: "BTL 2" },
        { question: "Examine the nature of the series 1 + 2 + 3 + ... + n + ...", marks: 2, co: "5", btl: "BTL 1" },
        { question: "State the Cauchy's integral test for convergence of positive term series.", marks: 2, co: "5", btl: "BTL 1" }
      ]
    },
    partB: {
      totalMarks: 30,
      questions: [
        { question: "Derive the relation between Gamma and Beta functions and hence compute the value of Γ(1/2).", marks: 10, co: "4", btl: "BTL 4", isImportant: true },
        { question: "Show that β(m,n) = ∫₀^∞ [x^(m-1)/(1+x)^(m+n)] dx.", marks: 10, co: "4", btl: "BTL 4", isImportant: true },
        { question: "A rectangular box open at the top is to have volume of 32 cubic metre. Compute the dimensions of the box requiring least material for its construction.", marks: 10, co: "3", btl: "BTL 3" },
        { question: "Change the order of integration in ∫∫e^(-(x²+y²)) dx dy.", marks: 10, co: "3", btl: "BTL 3", isImportant: true },
        { question: "Evaluate ∫∫∫ xyz dx dy dz taken over the positive octant of the sphere x² + y² + z² = 1.", marks: 10, co: "6", btl: "BTL 3" }
      ]
    },
    importantQuestions: [
      "Eigen values and Eigen vectors of matrices",
      "Partial derivatives and chain rule",
      "Double and triple integrals",
      "Differential equations using Laplace transform",
      "Series convergence tests",
      "Gamma and Beta functions"
    ]
  },
  {
    id: "els51001",
    courseCode: "ELS51001",
    courseName: "Communication Skills",
    department: "Languages",
    semester: "5",
    examDate: "April 2023",
    maxMarks: 100,
    duration: "3 hours",
    partA: {
      totalMarks: 20,
      questions: [
        { question: "Fill in the blanks with suitable tense form selecting from the choices given: When the thief entered the house the inmates ___ in the hall. (were slept/were sleeping/had been sleeping)", marks: 2, co: "1", btl: "BTL 2", isImportant: true },
        { question: "Identify the type of sentence: Did I say anything to make you angry?", marks: 2, co: "1", btl: "BTL 2" },
        { question: "Select the right modal verb from the given sentences: I ___ help you, but don't want to.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Complete the sentences with correct expressions from the given list: (therefore, due to, consequently, owing to, as a result)", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Give a brief introduction about yourself. (maximum 10 lines)", marks: 2, co: "3", btl: "BTL 2" },
        { question: "Develop the following hints given, into a readable passage.", marks: 2, co: "3", btl: "BTL 3" },
        { question: "Choose which part of speech the underlined word is: He often plays the trumpet. (noun/pronoun/verb)", marks: 2, co: "4", btl: "BTL 2", isImportant: true },
        { question: "They listen to music every day. (noun/pronoun/verb)", marks: 2, co: "4", btl: "BTL 2" },
        { question: "Choose the correct option from the bracket: The weather in weather between my country and that in the United Kingdom is very noticeable (1) compare (2) contrast (3) comparison", marks: 2, co: "5", btl: "BTL 4" },
        { question: "The United Kingdom and my country ___ a lot in many respects. (1) differ (2) different (3) differentiate", marks: 2, co: "5", btl: "BTL 4" }
      ]
    },
    partB: {
      totalMarks: 30,
      questions: [
        { question: "Imagine you are Shankar/Swathi of 16, TNagar, Chennai. You would like to apply for the post of Associate Marketing Manager in a reputed firm in Delhi. Write a covering letter to the Public Relations Officer.", marks: 12, co: "1", btl: "BTL 4", isImportant: true },
        { question: "Assume you are Madhav/Sneha living at C-25, Ramesh Nagar, Mumbai. In the main market of your block during these few women have experienced losing their gold chains and ear rings snatched by young boys riding on bike. You are very much worried. Write an advertisement to the Editor of a local newspaper.", marks: 12, co: "2", btl: "BTL 4", isImportant: true },
        { question: "Include the verbs in the gerund or infinitive form: We decided ___ (buy) a new car.", marks: 6, co: "3", btl: "BTL 3" },
        { question: "Put the words in the appropriate form (use prefixes or suffixes): He was acting in a very ___ childish way. (child)", marks: 6, co: "4", btl: "BTL 3" },
        { question: "Identify the errors and rewrite the sentences. Underline the correction made: He swam across the lake.", marks: 6, co: "5", btl: "BTL 3" }
      ]
    },
    importantQuestions: [
      "Tense forms and their applications",
      "Types of sentences",
      "Modal verbs and their usage",
      "Parts of speech and their functions",
      "Formal letter writing",
      "Paragraph development and cohesion",
      "Error identification and correction"
    ]
  },
  {
    id: "eph51001",
    courseCode: "EPH51001",
    courseName: "Engineering Physics",
    department: "Physics",
    semester: "5",
    examDate: "April 2023",
    maxMarks: 100,
    duration: "3 hours",
    partA: {
      totalMarks: 20,
      questions: [
        { question: "Define Hooke's law.", marks: 2, co: "1", btl: "BTL 2", isImportant: true },
        { question: "List the properties of ultrasonic waves.", marks: 2, co: "1", btl: "BTL 1" },
        { question: "Distinguish between primitive cell and unit cell.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "Define thermal conductivity and write its unit.", marks: 2, co: "2", btl: "BTL 2" },
        { question: "What is blackbody radiation? Draw the intensity distribution graph for a blackbody.", marks: 2, co: "3", btl: "BTL 2", isImportant: true },
        { question: "What are the physical significance of wavefunction?", marks: 2, co: "3", btl: "BTL 3" },
        { question: "What are the differences between an intrinsic and extrinsic semiconductor?", marks: 2, co: "4", btl: "BTL 2" },
        { question: "Write a note on anti-ferromagnetic materials.", marks: 2, co: "4", btl: "BTL 1" },
        { question: "Can a two-level system be used for the production of laser? Discuss your answer briefly.", marks: 2, co: "5", btl: "BTL 3", isImportant: true },
        { question: "What is the need of graded index fiber?", marks: 2, co: "5", btl: "BTL 3" }
      ]
    },
    partB: {
      totalMarks: 30,
      questions: [
        { question: "Discuss the experimental technique to determine Young's modulus uniform bending.", marks: 6, co: "1", btl: "BTL 2" },
        { question: "Explain the applications of ultrasonic waves in SONAR.", marks: 6, co: "1", btl: "BTL 2", isImportant: true },
        { question: "Explain the Bragg's law and its applications.", marks: 6, co: "2", btl: "BTL 3" },
        { question: "Derive the expression for the change in wavelength suffered by an X-ray photon when it collides with an electron at rest.", marks: 10, co: "3", btl: "BTL 3" },
        { question: "Solve the Schroedinger's equation for a particle in a one-dimensional box and obtain the Energy Eigen values and Eigen functions.", marks: 10, co: "3", btl: "BTL 3", isImportant: true }
      ]
    },
    importantQuestions: [
      "Hooke's law and elasticity",
      "Ultrasonic waves and applications",
      "Crystal structures and unit cells",
      "Blackbody radiation and Planck's law",
      "Quantum mechanics fundamentals",
      "Semiconductor properties",
      "Laser principles and applications"
    ]
  },
  {
    id: "ecs51001",
    courseCode: "ECS51001",
    courseName: "Programming Fundamentals Using C",
    department: "Computer Science",
    semester: "5",
    examDate: "November 2022",
    maxMarks: 100,
    duration: "3 hours",
    partA: {
      totalMarks: 20,
      questions: [
        { question: "Write the difference between algorithm and flowchart.", marks: 2, co: "1", btl: "BTL 2", isImportant: true },
        { question: "List out the types of programming language.", marks: 2, co: "1", btl: "BTL 1" },
        { question: "Give the different operators in C language.", marks: 2, co: "2", btl: "BTL 1" },
        { question: "Show how break and continue statements are used in a C program.", marks: 3, co: "2", btl: "BTL 3" },
        { question: "Define Recursion.", marks: 2, co: "3", btl: "BTL 1" },
        { question: "Mention the various String Manipulation Functions in C.", marks: 2, co: "3", btl: "BTL 2", isImportant: true },
        { question: "What are the uses of Pointers?", marks: 2, co: "4", btl: "BTL 2" },
        { question: "Compare structure and union.", marks: 2, co: "4", btl: "BTL 2" },
        { question: "What is the purpose of Embedded systems?", marks: 2, co: "5", btl: "BTL 1" },
        { question: "State Keil C51 compiler.", marks: 2, co: "5", btl: "BTL 2" }
      ]
    },
    partB: {
      totalMarks: 30,
      questions: [
        { question: "Explain in detail about the classification of computers.", marks: 6, co: "1", btl: "BTL 2", isImportant: true },
        { question: "What is flowchart? Explain different symbols used for flowchart.", marks: 6, co: "1", btl: "BTL 2" },
        { question: "Explain about input and output devices with an example.", marks: 6, co: "1", btl: "BTL 2" },
        { question: "Discuss the various data types in C with suitable examples.", marks: 6, co: "2", btl: "BTL 3", isImportant: true },
        { question: "Elaborate on the following operators in C language with an example program: a) Conditional operators, b) Assignment operators", marks: 6, co: "2", btl: "BTL 3", isImportant: true }
      ]
    },
    importantQuestions: [
      "Algorithm design and flowchart creation",
      "Data types and operators in C",
      "Control structures: loops and conditionals",
      "Functions and recursion",
      "Arrays and strings in C",
      "Pointers and memory management",
      "Structures and unions",
      "File handling in C"
    ]
  }
]
