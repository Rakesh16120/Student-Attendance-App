class ChatBot {
  constructor() {
    this.chatMessages = document.getElementById("chatMessages")
    this.chatInput = document.getElementById("chatInput")
    this.sendButton = document.getElementById("sendButton")
    this.typingIndicator = document.getElementById("typingIndicator")

    this.responses = {
      attendance: [
        "Your current attendance is 85%. You need to maintain at least 75% to be eligible for exams.",
        "Based on your attendance record, you've missed 3 classes this month. Try to attend regularly!",
        "Your attendance in Mathematics is 92%, Physics is 78%, and Chemistry is 88%.",
      ],
      timetable: [
        "Today you have Mathematics at 9:00 AM, Physics at 11:00 AM, and Chemistry Lab at 2:00 PM.",
        "Your next class is Physics at 11:00 AM in Room 204.",
        "Tomorrow's schedule: English at 9:00 AM, Mathematics at 10:30 AM, and Computer Science at 2:00 PM.",
      ],
      exam: [
        "Your next exam is Mathematics on March 15th. Make sure to complete your syllabus!",
        "Mid-term exams are scheduled from March 10-20. Check the notice board for detailed schedule.",
        "You have 2 pending assignments in Physics. Submit them before the deadline.",
      ],
      default: [
        "I'm here to help with your academic queries. Ask me about attendance, timetables, or exams!",
        "How can I assist you with your studies today?",
        "Feel free to ask me about your classes, attendance, or any academic information.",
        "I can help you with attendance tracking, schedule information, and exam details.",
      ],
    }

    this.initializeEventListeners()
  }

  initializeEventListeners() {
    this.sendButton.addEventListener("click", () => this.sendMessage())
    this.chatInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        this.sendMessage()
      }
    })
  }

  sendMessage() {
    const message = this.chatInput.value.trim()
    if (!message) return

    this.addMessage(message, "user")
    this.chatInput.value = ""

    this.showTypingIndicator()

    setTimeout(() => {
      this.hideTypingIndicator()
      const response = this.generateResponse(message)
      this.addMessage(response, "bot")
    }, 1500)
  }

  addMessage(text, sender) {
    const messageDiv = document.createElement("div")
    messageDiv.className = `message ${sender}-message`
    messageDiv.textContent = text

    this.chatMessages.appendChild(messageDiv)
    this.scrollToBottom()
  }

  generateResponse(userMessage) {
    const message = userMessage.toLowerCase()

    if (message.includes("attendance") || message.includes("present") || message.includes("absent")) {
      return this.getRandomResponse("attendance")
    } else if (
      message.includes("timetable") ||
      message.includes("schedule") ||
      message.includes("class") ||
      message.includes("time")
    ) {
      return this.getRandomResponse("timetable")
    } else if (
      message.includes("exam") ||
      message.includes("test") ||
      message.includes("assignment") ||
      message.includes("marks")
    ) {
      return this.getRandomResponse("exam")
    } else {
      return this.getRandomResponse("default")
    }
  }

  getRandomResponse(category) {
    const responses = this.responses[category]
    return responses[Math.floor(Math.random() * responses.length)]
  }

  showTypingIndicator() {
    this.typingIndicator.style.display = "block"
    this.scrollToBottom()
  }

  hideTypingIndicator() {
    this.typingIndicator.style.display = "none"
  }

  scrollToBottom() {
    this.chatMessages.scrollTop = this.chatMessages.scrollHeight
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new ChatBot()
})
