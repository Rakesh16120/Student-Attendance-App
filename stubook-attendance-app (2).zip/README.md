# Stubook - Student Attendance Management System

## Complete HTML/CSS/JavaScript Implementation

This is a fully functional student attendance management system for Hindustan University built with pure HTML, CSS, and JavaScript.

## Files Included

1. **index.html** - Login page with three user roles
2. **student-dashboard.html** - Student portal with timetable and attendance
3. **staff-dashboard.html** - Staff interface for marking attendance
4. **admin-dashboard.html** - Admin panel for system management
5. **chat.html** - AI chatbot for student queries

## Login Credentials

### Student
- Username: STU001
- Password: saiteja12

### Staff
- Username: STAFF001
- Password: rakesh12

### Admin
- Username: ADMIN001
- Password: password123

## Features

### Student Portal
- View weekly timetable with subjects and faculty
- Check attendance percentage for each subject
- View overall attendance statistics
- Access AI chatbot for academic queries
- Logout functionality

### Staff Portal
- Mark student attendance by subject and class
- Select date for attendance marking
- View student list with roll numbers
- Submit attendance records
- Logout functionality

### Admin Portal
- View system statistics (total students, staff, classes)
- Manage student records
- Manage staff members
- View recent activities
- Logout functionality

### AI Chatbot
- Answer questions about attendance
- Provide timetable information
- Share exam and assignment details
- Intelligent keyword-based responses

## How to Use

1. Save each HTML file in the same folder
2. Open `index.html` in your web browser
3. Login with the provided credentials
4. Navigate through the respective dashboards

## Technical Details

- Pure HTML5, CSS3, and Vanilla JavaScript
- No external dependencies required
- Responsive design for mobile and desktop
- Local storage for session management
- Modern UI with smooth animations

## File Structure

\`\`\`
stubook/
├── index.html
├── student-dashboard.html
├── staff-dashboard.html
├── admin-dashboard.html
└── chat.html
\`\`\`

## Browser Compatibility

Works on all modern browsers:
- Chrome
- Firefox
- Safari
- Edge

## Notes

- All data is stored in browser's local storage
- Attendance data is not persisted (for demo purposes)
- Each file is self-contained with embedded CSS and JavaScript
