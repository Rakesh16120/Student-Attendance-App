"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send, Search } from "lucide-react"

const MESSAGES = [
  { id: 1, sender: "Saiteja K", preview: "When will the results be declared?", time: "2 min ago", unread: true },
  { id: 2, sender: "Priya Sharma", preview: "Thank you for the project guidelines", time: "15 min ago", unread: true },
  { id: 3, sender: "Rahul Verma", preview: "Can we reschedule the lab session?", time: "1 hour ago", unread: false },
  { id: 4, sender: "Neha Gupta", preview: "Need clarification on assignments", time: "3 hours ago", unread: false },
  { id: 5, sender: "Class VI CSE", preview: "Seminar scheduled for tomorrow", time: "1 day ago", unread: false },
]

export function MessagePage() {
  const [selectedMessage, setSelectedMessage] = useState(MESSAGES[0])
  const [messageText, setMessageText] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredMessages = MESSAGES.filter(
    (msg) =>
      msg.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.preview.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Messages</h1>
        <p className="text-slate-400">Communication with students and staff</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message List */}
        <Card className="bg-slate-800 border-slate-700 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-white text-lg">Inbox</CardTitle>
            <div className="mt-4 relative">
              <Search className="absolute left-3 top-3 text-slate-400" size={18} />
              <Input
                placeholder="Search messages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500 pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {filteredMessages.map((msg) => (
                <button
                  key={msg.id}
                  onClick={() => setSelectedMessage(msg)}
                  className={`w-full text-left p-3 rounded-lg transition-colors ${
                    selectedMessage.id === msg.id
                      ? "bg-purple-600"
                      : "bg-slate-700/50 hover:bg-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {msg.unread && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-medium truncate">{msg.sender}</p>
                      <p className="text-slate-400 text-sm truncate">{msg.preview}</p>
                    </div>
                  </div>
                  <p className="text-slate-500 text-xs mt-1">{msg.time}</p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Message Detail */}
        <Card className="bg-slate-800 border-slate-700 lg:col-span-2">
          <CardHeader className="border-b border-slate-700">
            <CardTitle className="text-white">{selectedMessage.sender}</CardTitle>
            <p className="text-slate-400 text-sm mt-1">{selectedMessage.time}</p>
          </CardHeader>
          <CardContent className="flex flex-col h-96">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              <div className="bg-slate-700/50 p-4 rounded-lg max-w-xs">
                <p className="text-slate-300">{selectedMessage.preview}</p>
              </div>
              <div className="bg-purple-600 p-4 rounded-lg max-w-xs ml-auto">
                <p className="text-white">Response will be shown here</p>
              </div>
            </div>

            {/* Reply */}
            <div className="border-t border-slate-700 pt-4 mt-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Type your message..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
                <Button className="bg-purple-600 hover:bg-purple-700">
                  <Send size={18} />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
