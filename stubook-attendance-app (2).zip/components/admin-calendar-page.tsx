"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"

const EVENTS = [
  { date: "2025-03-15", title: "Semester Exam Starts", type: "exam" },
  { date: "2025-03-25", title: "Project Submission Deadline", type: "deadline" },
  { date: "2025-04-01", title: "Result Declaration", type: "result" },
  { date: "2025-04-10", title: "Summer Internship Begins", type: "event" },
  { date: "2025-05-01", title: "Mid-sem Break", type: "holiday" },
]

export function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date(2025, 2)) // March 2025

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay()
  }

  const days = []
  const firstDay = getFirstDayOfMonth(currentMonth)
  const daysInMonth = getDaysInMonth(currentMonth)

  for (let i = 0; i < firstDay; i++) {
    days.push(null)
  }
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i)
  }

  const monthName = currentMonth.toLocaleString("default", { month: "long", year: "numeric" })

  const getEventForDate = (day: number) => {
    const dateStr = `2025-${String(currentMonth.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return EVENTS.find((e) => e.date === dateStr)
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "exam":
        return "bg-red-500/20 text-red-400"
      case "deadline":
        return "bg-orange-500/20 text-orange-400"
      case "result":
        return "bg-blue-500/20 text-blue-400"
      case "event":
        return "bg-purple-500/20 text-purple-400"
      case "holiday":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-slate-500/20 text-slate-400"
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Academic Calendar</h1>
        <p className="text-slate-400">Important dates and events</p>
      </div>

      {/* Calendar */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white">{monthName}</CardTitle>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
              className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <ChevronLeft className="text-white" size={20} />
            </button>
            <button
              onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
              className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <ChevronRight className="text-white" size={20} />
            </button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Weekdays */}
          <div className="grid grid-cols-7 gap-2 mb-4">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div key={day} className="text-center text-slate-400 font-bold py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Days */}
          <div className="grid grid-cols-7 gap-2">
            {days.map((day, idx) => {
              const event = day ? getEventForDate(day) : null
              return (
                <div
                  key={idx}
                  className={`p-3 rounded-lg border border-slate-700 min-h-24 flex flex-col ${
                    day ? "bg-slate-700/50 hover:bg-slate-700 transition-colors cursor-pointer" : "bg-slate-800/30"
                  }`}
                >
                  {day && <p className="text-white font-bold mb-2">{day}</p>}
                  {event && (
                    <div className={`text-xs p-2 rounded ${getTypeColor(event.type)}`}>
                      {event.title}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Events List */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Upcoming Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {EVENTS.map((event, idx) => (
              <div key={idx} className="flex items-center gap-4 p-3 bg-slate-700/50 rounded-lg">
                <div
                  className={`w-3 h-3 rounded-full ${
                    event.type === "exam"
                      ? "bg-red-500"
                      : event.type === "deadline"
                        ? "bg-orange-500"
                        : event.type === "result"
                          ? "bg-blue-500"
                          : event.type === "event"
                            ? "bg-purple-500"
                            : "bg-green-500"
                  }`}
                />
                <div className="flex-1">
                  <p className="text-white font-medium">{event.title}</p>
                  <p className="text-slate-400 text-sm">{event.date}</p>
                </div>
                <span className={`text-xs px-3 py-1 rounded-full ${getTypeColor(event.type)}`}>
                  {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
