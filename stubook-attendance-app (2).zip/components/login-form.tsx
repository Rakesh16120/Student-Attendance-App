"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useRouter } from "next/navigation"
import { authenticateUser, setCurrentUser } from "@/lib/auth"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function LoginForm() {
  const [userType, setUserType] = useState<string>("student")
  const [userId, setUserId] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    const user = authenticateUser(userId, password)

    if (user && user.type === userType) {
      setCurrentUser(user)
      if (userType === "student") {
        router.push("/student/dashboard")
      } else if (userType === "staff") {
        router.push("/staff/dashboard")
      } else if (userType === "admin") {
        router.push("/admin/dashboard")
      }
    } else {
      setError("Invalid credentials or user type mismatch")
    }

    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary to-primary/90 flex flex-col">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-6 text-center">
        <h1 className="text-2xl font-bold">Stubook - Hindustan University</h1>
        <p className="text-primary-foreground/80 mt-2">Login</p>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4 bg-muted/30">
        <Card className="w-full max-w-md bg-background shadow-xl">
          <CardHeader className="text-center pb-4">
            <h2 className="text-xl font-semibold text-foreground">Welcome Back</h2>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {/* Login As Dropdown */}
              <div className="space-y-2">
                <Label htmlFor="userType" className="text-sm font-medium">
                  Login As:
                </Label>
                <Select value={userType} onValueChange={setUserType}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Student" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="staff">Staff</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* ID Field */}
              <div className="space-y-2">
                <Label htmlFor="userId" className="text-sm font-medium">
                  ID:
                </Label>
                <Input
                  id="userId"
                  type="text"
                  placeholder="Enter your ID"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full"
                  required
                />
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">
                  Password:
                </Label>
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full"
                  required
                />
              </div>

              {/* Show Password Checkbox */}
              <div className="flex items-center space-x-2">
                <Checkbox id="showPassword" checked={showPassword} onCheckedChange={setShowPassword} />
                <Label htmlFor="showPassword" className="text-sm">
                  Show Password
                </Label>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={isLoading || !userType || !userId || !password}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>

              {/* Forgot Password Link */}
              <div className="text-center">
                <button type="button" className="text-sm text-primary hover:underline">
                  Forgot Password?
                </button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="bg-primary text-primary-foreground py-4 text-center">
        <p className="text-sm">© 2024 Stubook - Hindustan University</p>
      </div>
    </div>
  )
}
