"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, Clock } from "lucide-react"

interface AttendanceRecord {
  subject: string
  totalClasses: number
  attendedClasses: number
  percentage: number
  status: "good" | "warning" | "critical"
}

const mockAttendanceData: AttendanceRecord[] = [
  { subject: "Data Structures", totalClasses: 45, attendedClasses: 42, percentage: 93, status: "good" },
  { subject: "Database Management", totalClasses: 40, attendedClasses: 35, percentage: 87, status: "good" },
  { subject: "Web Development", totalClasses: 38, attendedClasses: 30, percentage: 79, status: "warning" },
  { subject: "Algorithms", totalClasses: 42, attendedClasses: 38, percentage: 90, status: "good" },
  { subject: "Software Engineering", totalClasses: 35, attendedClasses: 25, percentage: 71, status: "warning" },
  { subject: "Mobile App Development", totalClasses: 30, attendedClasses: 18, percentage: 60, status: "critical" },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "good":
      return "bg-green-100 text-green-800 border-green-200"
    case "warning":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "critical":
      return "bg-red-100 text-red-800 border-red-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getStatusIcon = (status: string) => {
  switch (status) {
    case "good":
      return <CheckCircle className="h-4 w-4 text-green-600" />
    case "warning":
      return <Clock className="h-4 w-4 text-yellow-600" />
    case "critical":
      return <XCircle className="h-4 w-4 text-red-600" />
    default:
      return <Clock className="h-4 w-4 text-gray-600" />
  }
}

export function AttendanceOverview() {
  const overallAttendance = Math.round(
    mockAttendanceData.reduce((sum, record) => sum + record.percentage, 0) / mockAttendanceData.length,
  )

  return (
    <div className="space-y-6">
      {/* Overall Attendance Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-2xl font-bold text-foreground">{overallAttendance}%</p>
              <p className="text-sm text-muted-foreground">Overall Attendance</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-semibold text-foreground">
                {mockAttendanceData.reduce((sum, record) => sum + record.attendedClasses, 0)} /{" "}
                {mockAttendanceData.reduce((sum, record) => sum + record.totalClasses, 0)}
              </p>
              <p className="text-sm text-muted-foreground">Classes Attended</p>
            </div>
          </div>
          <Progress value={overallAttendance} className="h-2" />
        </CardContent>
      </Card>

      {/* Subject-wise Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Subject-wise Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockAttendanceData.map((record, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(record.status)}
                    <h3 className="font-semibold text-foreground">{record.subject}</h3>
                  </div>
                  <Badge className={getStatusColor(record.status)}>{record.percentage}%</Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>
                      Classes: {record.attendedClasses} / {record.totalClasses}
                    </span>
                    <span>{record.totalClasses - record.attendedClasses} missed</span>
                  </div>
                  <Progress value={record.percentage} className="h-2" />
                </div>

                {record.status === "critical" && (
                  <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-800">
                    ⚠️ Attendance below 75%. Risk of detention.
                  </div>
                )}
                {record.status === "warning" && (
                  <div className="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
                    ⚠️ Attendance below 85%. Improve attendance.
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
