"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import { useRouter } from "next/navigation"
import { logout } from "@/lib/auth"

// Subject data matching the provided timetable image
const subjectData = {
  ECS51013: { name: "Theory of Computation", color: "bg-cyan-200", faculty: "Dr. A. Edwin Raj" },
  ECS51012: { name: "Computer Architecture", color: "bg-cyan-300", faculty: "Dr. Jaya S" },
  ECS51014: { name: "Java Programming (Data Science Lab)", color: "bg-green-200", faculty: "Mr. Vishnu Sekhar" },
  ECS51803: { name: "Design Project - 3", color: "bg-pink-200", faculty: "Ms. J. Swarnalakshmi" },
  GLSS1005: { name: "Public Speaking", color: "bg-yellow-200", faculty: "Dr. Binu VS" },
  EGE51004: { name: "Entrepreneurship (Padur Hall II)", color: "bg-blue-200", faculty: "Dr. Leena Jenefia" },
  ECS51804: { name: "Internship -2", color: "bg-orange-200", faculty: "Class Teacher" },
  NE: { name: "Not Engaged", color: "bg-gray-100", faculty: "" },
  BREAK: { name: "Break", color: "bg-gray-200", faculty: "" },
  LUNCH: { name: "Lunch", color: "bg-gray-300", faculty: "" },
  MENTOR: { name: "Mentor", color: "bg-purple-200", faculty: "Class Teacher" },
  LIB: { name: "Library", color: "bg-indigo-200", faculty: "Class Teacher" },
  SEM: { name: "Seminar", color: "bg-teal-200", faculty: "All Core Subjects Staff Weekly" },
  DE: { name: "Design Elective", color: "bg-red-200", faculty: "" },
}

const timeSlots = [
  "8.30-9.20",
  "9.20-10.10",
  "10.10-10.30",
  "10.30-11.20",
  "11.20-12.10",
  "12.10-01.00",
  "01.00-01.50",
  "01.50-2.40",
  "2.40-3.30",
  "03.30-04.00",
]

const periods = ["1", "2", "BREAK", "3", "4", "LUNCH", "5", "6", "7", "8"]

const weeklySchedule = {
  MON: ["ECS51013", "ECS51012", "BREAK", "NE", "NE", "LUNCH", "ECS51014", "ECS51013", "LIB", ""],
  TUE: ["NE", "NE", "BREAK", "ECS51014", "ECS51013", "LUNCH", "ECS51012", "EGE51004", "EGE51004", ""],
  WED: ["ECS51012", "ECS51012", "BREAK", "MENTOR", "", "LUNCH", "", "ECS51013", "", ""],
  THU: ["ECS51014", "ECS51014", "BREAK", "ECS51803", "ECS51803", "LUNCH", "GLSS1005", "DE", "", ""],
  FRI: ["ECS51014", "ECS51012", "BREAK", "DE", "DE", "LUNCH", "GLSS1005", "SEM", "", ""],
}

// Mock attendance data for each subject
const attendanceData = {
  ECS51013: { attended: 28, total: 32, percentage: 87.5 },
  ECS51012: { attended: 25, total: 30, percentage: 83.3 },
  ECS51014: { attended: 22, total: 25, percentage: 88.0 },
  ECS51803: { attended: 18, total: 20, percentage: 90.0 },
  GLSS1005: { attended: 15, total: 18, percentage: 83.3 },
  EGE51004: { attended: 12, total: 15, percentage: 80.0 },
  ECS51804: { attended: 8, total: 10, percentage: 80.0 },
}

export function DetailedTimetable() {
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  // Calculate overall attendance
  const totalAttended = Object.values(attendanceData).reduce((sum, subject) => sum + subject.attended, 0)
  const totalClasses = Object.values(attendanceData).reduce((sum, subject) => sum + subject.total, 0)
  const overallPercentage = ((totalAttended / totalClasses) * 100).toFixed(1)

  return (
    <div className="space-y-6">
      {/* Header with logout button */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Time Table</h2>
          <div className="text-sm text-muted-foreground mt-1">
            <p>Department: CSE | Class: V | Section: F | Class Strength: 66</p>
            <p>Class Teacher: Ms. MADHUMATHI | Room No: PX304/Lab</p>
          </div>
        </div>
        <Button onClick={handleLogout} variant="outline" className="flex items-center gap-2 bg-transparent">
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>

      {/* Overall Attendance */}
      <Card>
        <CardContent className="p-4">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-foreground mb-2">Overall Attendance</h3>
            <div className="text-3xl font-bold text-primary">{overallPercentage}%</div>
            <p className="text-sm text-muted-foreground">
              {totalAttended} out of {totalClasses} classes attended
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Timetable */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Schedule</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              {/* Header Row */}
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-2 text-sm font-semibold">TIME</th>
                  {timeSlots.map((time, index) => (
                    <th key={index} className="border border-gray-300 p-2 text-xs font-semibold min-w-[80px]">
                      {time}
                    </th>
                  ))}
                </tr>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-2 text-sm font-semibold">PERIOD</th>
                  {periods.map((period, index) => (
                    <th key={index} className="border border-gray-300 p-2 text-xs font-semibold">
                      {period}
                    </th>
                  ))}
                </tr>
              </thead>

              {/* Schedule Rows */}
              <tbody>
                {Object.entries(weeklySchedule).map(([day, schedule]) => (
                  <tr key={day}>
                    <td className="border border-gray-300 p-2 font-semibold text-sm bg-gray-50">{day}</td>
                    {schedule.map((subjectCode, index) => (
                      <td
                        key={index}
                        className={`border border-gray-300 p-1 text-xs text-center ${
                          subjectCode && subjectData[subjectCode as keyof typeof subjectData]
                            ? subjectData[subjectCode as keyof typeof subjectData].color
                            : "bg-white"
                        }`}
                      >
                        {subjectCode && subjectCode !== "" ? <div className="font-semibold">{subjectCode}</div> : null}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Subject-wise Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Subject-wise Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(attendanceData).map(([subjectCode, data]) => {
              const subject = subjectData[subjectCode as keyof typeof subjectData]
              return (
                <Card key={subjectCode} className="border-l-4 border-l-primary">
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-sm">{subjectCode}</h4>
                        <Badge
                          variant={
                            data.percentage >= 85 ? "default" : data.percentage >= 75 ? "secondary" : "destructive"
                          }
                        >
                          {data.percentage.toFixed(1)}%
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{subject?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {data.attended}/{data.total} classes attended
                      </p>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            data.percentage >= 85
                              ? "bg-green-500"
                              : data.percentage >= 75
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                          style={{ width: `${data.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
