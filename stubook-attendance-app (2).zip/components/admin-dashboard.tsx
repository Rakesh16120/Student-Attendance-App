"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { STUDENT_DATA } from "@/lib/student-data"
import { ClassesPage } from "./admin-classes-page"
import { CalendarPage } from "./admin-calendar-page"
import { ActivityPage } from "./admin-activity-page"
import { MessagePage } from "./admin-message-page"
import { ReportPage } from "./admin-report-page"
import {
  LayoutDashboard,
  Calendar,
  Users,
  Activity,
  MessageSquare,
  FileText,
  DollarSign,
  Settings,
  HelpCircle,
  Menu,
  X,
  TrendingUp,
  BookOpen,
  Award,
} from "lucide-react"

type StudentRecord = (typeof STUDENT_DATA)[0]

const SIDEBAR_ITEMS = [
  { icon: LayoutDashboard, label: "Dashboard", id: "dashboard" },
  { icon: Calendar, label: "Calendar", id: "calendar" },
  { icon: Users, label: "Classes", id: "classes" },
  { icon: Activity, label: "Activity", id: "activity" },
  { icon: MessageSquare, label: "Message", id: "message" },
  { icon: FileText, label: "Report", id: "report" },
  { icon: DollarSign, label: "Payroll", id: "payroll" },
  { icon: Settings, label: "Settings", id: "settings" },
  { icon: HelpCircle, label: "Help & Support", id: "help" },
]

const STATS = [
  {
    label: "Total Students",
    value: "240",
    change: "+12% from last quarter",
    icon: Users,
    color: "from-blue-500 to-blue-600",
  },
  {
    label: "New Applications",
    value: "24",
    change: "+8% from last quarter",
    icon: BookOpen,
    color: "from-purple-500 to-purple-600",
  },
  {
    label: "Average GPA",
    value: "3.76",
    change: "+0.5 from last semester",
    icon: TrendingUp,
    color: "from-green-500 to-green-600",
  },
  {
    label: "Attendance Rate",
    value: "92%",
    change: "+5% from last quarter",
    icon: Award,
    color: "from-orange-500 to-orange-600",
  },
]

const performanceData = [
  { date: "1 Jun", performance: 75 },
  { date: "2 Jun", performance: 78 },
  { date: "3 Jun", performance: 82 },
  { date: "4 Jun", performance: 80 },
  { date: "5 Jun", performance: 85 },
  { date: "6 Jun", performance: 88 },
  { date: "7 Jun", performance: 87 },
]

const attendanceData = [
  { name: "Present", value: 220, fill: "#8B5CF6" },
  { name: "On Leave", value: 10, fill: "#FBBF24" },
  { name: "On Holiday", value: 5, fill: "#34D399" },
  { name: "Absent", value: 5, fill: "#EF4444" },
]

export function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [activePage, setActivePage] = useState<"dashboard" | "calendar" | "classes" | "activity" | "message" | "report" | "payroll" | "settings" | "help">("dashboard")

  // Calculate statistics
  const totalStudents = STUDENT_DATA.length
  const avgGPA = (STUDENT_DATA.reduce((sum, s) => sum + s.gpa, 0) / STUDENT_DATA.length).toFixed(2)
  const avgAttendance = (
    STUDENT_DATA.reduce((sum, s) => sum + s.attendance, 0) / STUDENT_DATA.length
  ).toFixed(0)

  // Filter students based on search
  const filteredStudents = STUDENT_DATA.filter(
    (student) =>
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchQuery.toLowerCase())
  ).slice(0, 8)

  return (
    <div className="flex h-screen bg-slate-950">
      {/* Sidebar */}
      <div
        className={`fixed md:static inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-slate-900 to-slate-950 border-r border-slate-800 transition-all duration-300 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">SB</span>
            </div>
            <span className="text-white font-bold text-lg">StuBook</span>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        <div className="px-4 space-y-2">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id as any)
                  setSidebarOpen(false)
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activePage === item.id
                    ? "bg-purple-600 text-white"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Icon size={20} />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            )
          })}
        </div>

        <div className="absolute bottom-4 left-4 right-4 p-4 bg-slate-800/50 rounded-lg border border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-xs">AM</span>
            </div>
            <div>
              <p className="text-white text-sm font-medium">Admin User</p>
              <p className="text-slate-400 text-xs">Administrator</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Top Bar */}
        <div className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 p-6">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden text-slate-400 hover:text-white"
            >
              <Menu size={24} />
            </button>
            <h1 className="text-2xl font-bold text-white">
              {activePage === "dashboard" && "Dashboard"}
              {activePage === "calendar" && "Calendar"}
              {activePage === "classes" && "Classes"}
              {activePage === "activity" && "Activity"}
              {activePage === "message" && "Messages"}
              {activePage === "report" && "Reports"}
              {activePage === "payroll" && "Payroll"}
              {activePage === "settings" && "Settings"}
              {activePage === "help" && "Help & Support"}
            </h1>
            <div className="w-96 relative hidden lg:block">
              <Input
                placeholder="Search something..."
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors">
                <Settings size={20} />
              </button>
            </div>
          </div>
          <p className="text-slate-400 text-sm mt-2">Here is today&apos;s report and performances</p>
        </div>

        {/* Main Content Area */}
        <div className="p-6 space-y-6">
          {/* Render different pages */}
          {activePage === "calendar" && <CalendarPage />}
          {activePage === "classes" && <ClassesPage />}
          {activePage === "activity" && <ActivityPage />}
          {activePage === "message" && <MessagePage />}
          {activePage === "report" && <ReportPage />}

          {/* Dashboard Content - shown when activePage is dashboard */}
          {activePage === "dashboard" && (
            <>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: "Total Students", value: totalStudents, color: "from-blue-500 to-blue-600" },
              { label: "Average GPA", value: avgGPA, color: "from-purple-500 to-purple-600" },
              { label: "Avg Attendance", value: `${avgAttendance}%`, color: "from-green-500 to-green-600" },
              { label: "Active Users", value: "234", color: "from-orange-500 to-orange-600" },
            ].map((stat, idx) => (
              <Card key={idx} className="bg-slate-800 border-slate-700 overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-slate-400 text-sm mb-2">{stat.label}</p>
                      <p className="text-3xl font-bold text-white">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} opacity-20`} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Performance Chart */}
            <Card className="lg:col-span-2 bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Student Performance</CardTitle>
                <CardDescription className="text-slate-400">Weekly progress</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1e293b",
                        border: "1px solid #334155",
                        borderRadius: "8px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="performance"
                      stroke="#8B5CF6"
                      strokeWidth={3}
                      dot={{ fill: "#8B5CF6", r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Attendance Pie Chart */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Attendance</CardTitle>
                <CardDescription className="text-slate-400">4 June 2024</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={attendanceData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={120}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {attendanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1e293b",
                        border: "1px solid #334155",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-2 text-sm">
                  {attendanceData.map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-slate-400">
                      <span className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }} />
                        {item.name}
                      </span>
                      <span className="text-white font-medium">{item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Students Table */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Students</CardTitle>
                  <CardDescription className="text-slate-400">Recent active students</CardDescription>
                </div>
                <Input
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">ID</th>
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">Name</th>
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">Class</th>
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">GPA</th>
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">Attendance</th>
                      <th className="text-left py-3 px-4 text-slate-400 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStudents.map((student) => (
                      <tr key={student.rollNo} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                        <td className="py-3 px-4 text-slate-300">{student.rollNo}</td>
                        <td className="py-3 px-4 text-white font-medium">{student.name}</td>
                        <td className="py-3 px-4 text-slate-300">{student.class}</td>
                        <td className="py-3 px-4 text-white font-medium">{student.gpa}</td>
                        <td className="py-3 px-4">
                          <div className="w-24 bg-slate-700 rounded-full h-2">
                            <div
                              className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-purple-600"
                              style={{ width: `${student.attendance}%` }}
                            />
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-medium">
                            Active
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
