"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { BarChart3, Download, TrendingUp, TrendingDown, Users } from "lucide-react"
import { useState } from "react"

interface ClassReport {
  className: string
  subject: string
  totalStudents: number
  averageAttendance: number
  lastClassAttendance: number
  trend: "up" | "down" | "stable"
}

const mockReports: ClassReport[] = [
  {
    className: "CS-3A",
    subject: "Data Structures",
    totalStudents: 45,
    averageAttendance: 87,
    lastClassAttendance: 91,
    trend: "up",
  },
  {
    className: "CS-3B",
    subject: "Data Structures",
    totalStudents: 42,
    averageAttendance: 82,
    lastClassAttendance: 78,
    trend: "down",
  },
  {
    className: "CS-3A",
    subject: "Algorithms",
    totalStudents: 45,
    averageAttendance: 89,
    lastClassAttendance: 89,
    trend: "stable",
  },
  {
    className: "CS-3C",
    subject: "Database Management",
    totalStudents: 38,
    averageAttendance: 75,
    lastClassAttendance: 82,
    trend: "up",
  },
]

const getTrendIcon = (trend: string) => {
  switch (trend) {
    case "up":
      return <TrendingUp className="h-4 w-4 text-green-600" />
    case "down":
      return <TrendingDown className="h-4 w-4 text-red-600" />
    default:
      return <BarChart3 className="h-4 w-4 text-gray-600" />
  }
}

const getTrendColor = (trend: string) => {
  switch (trend) {
    case "up":
      return "text-green-600"
    case "down":
      return "text-red-600"
    default:
      return "text-gray-600"
  }
}

export function AttendanceReports() {
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [selectedSubject, setSelectedSubject] = useState("all")

  const subjects = ["all", "Data Structures", "Algorithms", "Database Management"]
  const periods = [
    { value: "week", label: "This Week" },
    { value: "month", label: "This Month" },
    { value: "semester", label: "This Semester" },
  ]

  const filteredReports = mockReports.filter(
    (report) => selectedSubject === "all" || report.subject === selectedSubject,
  )

  const overallStats = {
    totalClasses: filteredReports.length,
    averageAttendance: Math.round(
      filteredReports.reduce((sum, report) => sum + report.averageAttendance, 0) / filteredReports.length,
    ),
    totalStudents: filteredReports.reduce((sum, report) => sum + report.totalStudents, 0),
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Reports & Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Time Period</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {periods.map((period) => (
                    <SelectItem key={period.value} value={period.value}>
                      {period.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Subject</label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject === "all" ? "All Subjects" : subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                <Download className="h-4 w-4" />
                <span>Export Report</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Overall Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Average Attendance</p>
                <p className="text-2xl font-bold text-foreground">{overallStats.averageAttendance}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-secondary" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold text-foreground">{overallStats.totalStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Classes</p>
                <p className="text-2xl font-bold text-foreground">{overallStats.totalClasses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Class-wise Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Class-wise Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredReports.map((report, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div>
                      <h3 className="font-semibold text-foreground">
                        {report.subject} - {report.className}
                      </h3>
                      <p className="text-sm text-muted-foreground">{report.totalStudents} students</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-lg font-bold">{report.averageAttendance}%</p>
                      <p className="text-xs text-muted-foreground">Average</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {getTrendIcon(report.trend)}
                      <span className={`text-sm font-medium ${getTrendColor(report.trend)}`}>
                        {report.lastClassAttendance}%
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Attendance Progress</span>
                    <span>{report.averageAttendance}%</span>
                  </div>
                  <Progress value={report.averageAttendance} className="h-2" />
                </div>

                <div className="mt-3 flex justify-between items-center">
                  <div className="flex space-x-2">
                    {report.averageAttendance >= 85 && (
                      <Badge className="bg-green-100 text-green-800 border-green-200">Excellent</Badge>
                    )}
                    {report.averageAttendance >= 75 && report.averageAttendance < 85 && (
                      <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Good</Badge>
                    )}
                    {report.averageAttendance < 75 && (
                      <Badge className="bg-red-100 text-red-800 border-red-200">Needs Attention</Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">Last class: {report.lastClassAttendance}%</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
