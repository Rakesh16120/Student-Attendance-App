"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, MessageCircle, Share2, TrendingUp, Award, Users } from "lucide-react"

const ACTIVITIES = [
  { user: "Saiteja K", action: "submitted assignment", subject: "Web Programming", time: "2 hours ago", type: "submission" },
  { user: "Priya Sharma", action: "scored 95 in", subject: "Compiler Design", time: "3 hours ago", type: "achievement" },
  { user: "Rahul Verma", action: "participated in", subject: "Tech Fest 2025", time: "5 hours ago", type: "event" },
  { user: "Neha Gupta", action: "completed", subject: "Project - VCC Implementation", time: "1 day ago", type: "project" },
  { user: "Arun Kumar", action: "joined", subject: "Internship Program", time: "1 day ago", type: "event" },
  { user: "class VI CSE", action: "achieved", subject: "90% average attendance", time: "2 days ago", type: "milestone" },
]

export function ActivityPage() {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "submission":
        return <MessageCircle className="text-blue-400" />
      case "achievement":
        return <Award className="text-yellow-400" />
      case "event":
        return <TrendingUp className="text-purple-400" />
      case "project":
        return <Users className="text-green-400" />
      case "milestone":
        return <Heart className="text-red-400" />
      default:
        return <Share2 className="text-slate-400" />
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Activity Feed</h1>
        <p className="text-slate-400">Student and class activities</p>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Activities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {ACTIVITIES.map((activity, idx) => (
              <div key={idx} className="flex gap-4 p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700 transition-colors">
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white">
                    <span className="font-semibold">{activity.user}</span>
                    {" "}
                    <span className="text-slate-300">{activity.action}</span>
                    {" "}
                    <span className="font-semibold text-purple-400">{activity.subject}</span>
                  </p>
                  <p className="text-slate-400 text-sm mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Activity Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Assignments Submitted</p>
            <p className="text-white text-3xl font-bold mt-2">238</p>
            <p className="text-green-400 text-sm mt-2">↑ 12 since yesterday</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Events Participated</p>
            <p className="text-white text-3xl font-bold mt-2">156</p>
            <p className="text-green-400 text-sm mt-2">↑ 8 this week</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Achievements Unlocked</p>
            <p className="text-white text-3xl font-bold mt-2">42</p>
            <p className="text-green-400 text-sm mt-2">↑ 3 this month</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
