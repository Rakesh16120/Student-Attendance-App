"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const CLASS_TIMETABLE = {
  department: "CSE",
  class: "VI Semester",
  teacher: "Ms. Madhumathi",
  room: "PG102",
  strength: 66,
  effectiveFrom: "01-12-2025",
  schedule: [
    { day: "MON", periods: ["ECS51015", "ECS51016", "-", "TRAINING COURSE", "-", "ECS51524, ECS51525, ECS51527, ECS51528, ECS51530, ECS51526", "MENTOR", "ECS51017"] },
    { day: "TUE", periods: ["ECS51015 CD Millenium Lab II", "-", "-", "ECS51805", "-", "TRAINING COURSE", "ECS51918", "-"] },
    { day: "WED", periods: ["ECS51016", "ECS51018", "BREAK", "ECS51017, LIB", "-", "LUNCH", "ECS51016", "ECS51018 VCC Data Science Lab, ECS51524, ECS51525, ECS51527, ECS51528, ECS51530, ECS51526"] },
    { day: "THU", periods: ["ECS51017", "SEMINAR", "-", "ECS51016 WP Millenium Lab I", "-", "-", "ECS51015", "ECS51018"] },
    { day: "FRI", periods: ["GLS51006", "GLS51006", "-", "ECS51524, ECS51525, ECS51527, ECS51528, ECS51530, ECS51526", "-", "-", "ECS51017", "LIB, ECS51015"] },
  ],
  timings: ["8:30-9:20", "9:20-10:10", "10:10-10:30", "10:30-11:20", "11:20-12:10", "12:10-01:00", "01:00-01:50", "01:50-2:40"],
}

const COURSES = [
  { code: "GLS51006", name: "English for Competitive Examinations", faculty: "Ms. Cynde Aieluarya", L: 0, T: 0, P: 2, C: 1 },
  { code: "ECS51015", name: "Principles of Compiler Design (Millenium Lab II)", faculty: "Dr. B Munica Jenefer", L: 2, T: 1, P: 2, C: 4 },
  { code: "ECS51016", name: "Web Programming (Millenium Lab I)", faculty: "Ms. Madhumathi", L: 2, T: 1, P: 2, C: 3 },
  { code: "ECS51017", name: "Artificial Intelligence and Expert Systems", faculty: "Dr. M. Mageshkubu", L: 3, T: 1, P: 0, C: 3 },
  { code: "ECS51018", name: "Virtualization and Cloud Computing (Data Science Lab)", faculty: "Mr. Sai Prasanth", L: 2, T: 1, P: 2, C: 3 },
  { code: "ECS51805", name: "Design Project - 4", faculty: "Dr. B Munica Jenefer", L: 0, T: 0, P: 2, C: 1 },
]

export function ClassesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Classes & Timetable</h1>
        <p className="text-slate-400">VI Semester Schedule and Course Details</p>
      </div>

      {/* Class Info */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Department</p>
            <p className="text-white text-xl font-bold">{CLASS_TIMETABLE.department}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Class</p>
            <p className="text-white text-xl font-bold">{CLASS_TIMETABLE.class}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Room</p>
            <p className="text-white text-xl font-bold">{CLASS_TIMETABLE.room}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Strength</p>
            <p className="text-white text-xl font-bold">{CLASS_TIMETABLE.strength}</p>
          </CardContent>
        </Card>
      </div>

      {/* Timetable */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Weekly Timetable</CardTitle>
          <CardDescription className="text-slate-400">Teacher: {CLASS_TIMETABLE.teacher}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-slate-700/50">
                  <th className="border border-slate-600 px-4 py-2 text-slate-300 text-left">Period</th>
                  {CLASS_TIMETABLE.timings.map((time, idx) => (
                    <th key={idx} className="border border-slate-600 px-4 py-2 text-slate-300 text-center">
                      {idx + 1}
                    </th>
                  ))}
                </tr>
                <tr className="bg-slate-700/50">
                  <th className="border border-slate-600 px-4 py-2 text-slate-300 text-left">Time</th>
                  {CLASS_TIMETABLE.timings.map((time, idx) => (
                    <th key={idx} className="border border-slate-600 px-4 py-2 text-slate-300 text-center text-xs">
                      {time}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CLASS_TIMETABLE.schedule.map((row, dayIdx) => (
                  <tr key={dayIdx} className="hover:bg-slate-700/30">
                    <td className="border border-slate-600 px-4 py-3 text-white font-bold bg-slate-700/30">{row.day}</td>
                    {row.periods.map((period, periodIdx) => (
                      <td key={periodIdx} className="border border-slate-600 px-4 py-3 text-slate-300 text-center text-xs">
                        {period === "-" ? "" : period}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Courses */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Course Details</CardTitle>
          <CardDescription className="text-slate-400">Courses and Faculty Information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Code</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Course Name</th>
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Faculty</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">L</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">T</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">P</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">C</th>
                </tr>
              </thead>
              <tbody>
                {COURSES.map((course) => (
                  <tr key={course.code} className="border-b border-slate-700 hover:bg-slate-700/50">
                    <td className="py-3 px-4 text-white font-mono">{course.code}</td>
                    <td className="py-3 px-4 text-white">{course.name}</td>
                    <td className="py-3 px-4 text-slate-300">{course.faculty}</td>
                    <td className="py-3 px-4 text-center text-slate-300">{course.L}</td>
                    <td className="py-3 px-4 text-center text-slate-300">{course.T}</td>
                    <td className="py-3 px-4 text-center text-slate-300">{course.P}</td>
                    <td className="py-3 px-4 text-center text-white font-bold">{course.C}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
