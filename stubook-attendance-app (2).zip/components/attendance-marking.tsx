"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Search, Save, Users, Clock } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Student {
  id: string
  name: string
  rollNumber: string
  year: number
  department: string
  isPresent: boolean
}

const mockStudents: Student[] = [
  { id: "1", name: "K SAITEJA", rollNumber: "STU001", year: 3, department: "Computer Science", isPresent: false },
  { id: "2", name: "Priya Sharma", rollNumber: "STU002", year: 3, department: "Computer Science", isPresent: false },
  { id: "3", name: "Amit Patel", rollNumber: "STU003", year: 3, department: "Computer Science", isPresent: false },
  { id: "4", name: "Sneha Gupta", rollNumber: "STU004", year: 3, department: "Computer Science", isPresent: false },
  { id: "5", name: "Vikram Singh", rollNumber: "STU005", year: 3, department: "Computer Science", isPresent: false },
  { id: "6", name: "Anita Verma", rollNumber: "STU006", year: 3, department: "Computer Science", isPresent: false },
  { id: "7", name: "Rajesh Kumar", rollNumber: "STU007", year: 3, department: "Computer Science", isPresent: false },
  { id: "8", name: "Pooja Agarwal", rollNumber: "STU008", year: 3, department: "Computer Science", isPresent: false },
  { id: "9", name: "Suresh Reddy", rollNumber: "STU009", year: 3, department: "Computer Science", isPresent: false },
  { id: "10", name: "Kavya Nair", rollNumber: "STU010", year: 3, department: "Computer Science", isPresent: false },
]

export function AttendanceMarking() {
  const [students, setStudents] = useState<Student[]>(mockStudents)
  const [selectedSubject, setSelectedSubject] = useState("")
  const [selectedClass, setSelectedClass] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)

  const subjects = ["Data Structures", "Algorithms", "Database Management"]
  const classes = ["CS-3A", "CS-3B", "CS-3C"]

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleStudentAttendance = (studentId: string, isPresent: boolean) => {
    setStudents((prev) => prev.map((student) => (student.id === studentId ? { ...student, isPresent } : student)))
  }

  const handleMarkAllPresent = () => {
    setStudents((prev) => prev.map((student) => ({ ...student, isPresent: true })))
  }

  const handleMarkAllAbsent = () => {
    setStudents((prev) => prev.map((student) => ({ ...student, isPresent: false })))
  }

  const handleSaveAttendance = async () => {
    if (!selectedSubject || !selectedClass) {
      return
    }

    setIsSaving(true)
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setSaveSuccess(true)
      setTimeout(() => setSaveSuccess(false), 3000)
    }, 1500)
  }

  const presentCount = students.filter((s) => s.isPresent).length
  const totalCount = students.length
  const attendancePercentage = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0

  return (
    <div className="space-y-6">
      {/* Class Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Class & Subject</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="subject">Subject</Label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="class">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((classItem) => (
                    <SelectItem key={classItem} value={classItem}>
                      {classItem}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedSubject && selectedClass && (
            <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">
                  {selectedSubject} - {selectedClass}
                </p>
                <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {selectedSubject && selectedClass && (
        <>
          {/* Attendance Summary */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Users className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-2xl font-bold">
                      {presentCount} / {totalCount}
                    </p>
                    <p className="text-sm text-muted-foreground">Students Present</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">{attendancePercentage}%</p>
                  <p className="text-sm text-muted-foreground">Attendance Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Student List */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Mark Attendance</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={handleMarkAllPresent}>
                    Mark All Present
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleMarkAllAbsent}>
                    Mark All Absent
                  </Button>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Search className="h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredStudents.map((student) => (
                  <div key={student.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <Checkbox
                        id={student.id}
                        checked={student.isPresent}
                        onCheckedChange={(checked) => handleStudentAttendance(student.id, checked as boolean)}
                      />
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {student.rollNumber} • Year {student.year}
                        </p>
                      </div>
                    </div>
                    <Badge variant={student.isPresent ? "default" : "secondary"}>
                      {student.isPresent ? "Present" : "Absent"}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end space-x-4">
            <Button onClick={handleSaveAttendance} disabled={isSaving} className="min-w-32">
              {isSaving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Attendance
                </>
              )}
            </Button>
          </div>

          {saveSuccess && (
            <Alert className="border-green-200 bg-green-50">
              <AlertDescription className="text-green-800">
                Attendance saved successfully for {selectedSubject} - {selectedClass}!
              </AlertDescription>
            </Alert>
          )}
        </>
      )}
    </div>
  )
}
