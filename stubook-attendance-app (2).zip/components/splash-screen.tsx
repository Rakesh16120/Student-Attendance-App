"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

interface SplashScreenProps {
  onComplete: () => void
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onComplete, 500) // Wait for fade out animation
    }, 3000) // Show splash for 3 seconds

    return () => clearTimeout(timer)
  }, [onComplete])

  return (
    <div
      className={`fixed inset-0 flex flex-col items-center justify-center z-50 transition-opacity duration-500 overflow-hidden ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
      style={{
        backgroundImage: `url('/university-background.jpg')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Dark overlay for better contrast */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
      
      {/* Content */}
      <div className="relative z-10 flex flex-col items-center space-y-8 animate-fade-in">
        <div className="relative w-80 h-80 md:w-96 md:h-96 animate-pulse drop-shadow-2xl">
          <Image
            src="/hindustan-university-logo.jpg"
            alt="Hindustan University - Hindustan Institute of Technology & Science"
            fill
            className="object-contain"
            priority
            quality={95}
            sizes="(max-width: 768px) 280px, 384px"
          />
        </div>

        <div className="text-center space-y-4 px-6">
          <h1 className="text-5xl md:text-6xl font-bold text-white drop-shadow-xl">Stubook</h1>
          <p className="text-xl md:text-2xl text-white drop-shadow-lg font-semibold">Hindustan University</p>
          <p className="text-base md:text-lg text-gray-100 drop-shadow-lg">Student Attendance Management System</p>
        </div>

        <div className="flex space-x-3 mt-10">
          <div className="w-3 h-3 bg-white rounded-full animate-bounce drop-shadow-lg"></div>
          <div className="w-3 h-3 bg-white rounded-full animate-bounce drop-shadow-lg" style={{ animationDelay: "0.1s" }}></div>
          <div className="w-3 h-3 bg-white rounded-full animate-bounce drop-shadow-lg" style={{ animationDelay: "0.2s" }}></div>
        </div>
      </div>
    </div>
  )
}
