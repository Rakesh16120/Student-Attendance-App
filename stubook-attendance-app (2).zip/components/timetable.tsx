"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, User } from "lucide-react"

interface ClassSchedule {
  id: string
  subject: string
  teacher: string
  time: string
  room: string
  type: "lecture" | "lab" | "tutorial"
}

const weekDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

const mockSchedule: Record<string, ClassSchedule[]> = {
  Monday: [
    {
      id: "1",
      subject: "Data Structures",
      teacher: "Dr. Anita Verma",
      time: "9:00 - 10:00",
      room: "CS-101",
      type: "lecture",
    },
    {
      id: "2",
      subject: "Database Management",
      teacher: "Prof. Rajesh Singh",
      time: "10:00 - 11:00",
      room: "CS-102",
      type: "lecture",
    },
    {
      id: "3",
      subject: "Web Development Lab",
      teacher: "Dr. Priya Sharma",
      time: "2:00 - 4:00",
      room: "Lab-1",
      type: "lab",
    },
  ],
  Tuesday: [
    {
      id: "4",
      subject: "Algorithms",
      teacher: "Dr. Anita Verma",
      time: "9:00 - 10:00",
      room: "CS-101",
      type: "lecture",
    },
    {
      id: "5",
      subject: "Software Engineering",
      teacher: "Prof. Kumar Patel",
      time: "11:00 - 12:00",
      room: "CS-103",
      type: "lecture",
    },
    {
      id: "6",
      subject: "Database Lab",
      teacher: "Prof. Rajesh Singh",
      time: "2:00 - 4:00",
      room: "Lab-2",
      type: "lab",
    },
  ],
  Wednesday: [
    {
      id: "7",
      subject: "Data Structures",
      teacher: "Dr. Anita Verma",
      time: "9:00 - 10:00",
      room: "CS-101",
      type: "lecture",
    },
    {
      id: "8",
      subject: "Mobile App Development",
      teacher: "Dr. Sanjay Gupta",
      time: "10:00 - 11:00",
      room: "CS-104",
      type: "lecture",
    },
    {
      id: "9",
      subject: "Tutorial - Algorithms",
      teacher: "Dr. Anita Verma",
      time: "3:00 - 4:00",
      room: "CS-101",
      type: "tutorial",
    },
  ],
  Thursday: [
    {
      id: "10",
      subject: "Database Management",
      teacher: "Prof. Rajesh Singh",
      time: "9:00 - 10:00",
      room: "CS-102",
      type: "lecture",
    },
    {
      id: "11",
      subject: "Software Engineering",
      teacher: "Prof. Kumar Patel",
      time: "10:00 - 11:00",
      room: "CS-103",
      type: "lecture",
    },
    {
      id: "12",
      subject: "Mobile App Lab",
      teacher: "Dr. Sanjay Gupta",
      time: "2:00 - 4:00",
      room: "Lab-3",
      type: "lab",
    },
  ],
  Friday: [
    {
      id: "13",
      subject: "Algorithms",
      teacher: "Dr. Anita Verma",
      time: "9:00 - 10:00",
      room: "CS-101",
      type: "lecture",
    },
    {
      id: "14",
      subject: "Mobile App Development",
      teacher: "Dr. Sanjay Gupta",
      time: "11:00 - 12:00",
      room: "CS-104",
      type: "lecture",
    },
    {
      id: "15",
      subject: "Project Work",
      teacher: "All Faculty",
      time: "2:00 - 4:00",
      room: "CS-105",
      type: "tutorial",
    },
  ],
  Saturday: [
    {
      id: "16",
      subject: "Seminar",
      teacher: "Guest Speaker",
      time: "10:00 - 12:00",
      room: "Auditorium",
      type: "lecture",
    },
  ],
}

const getTypeColor = (type: string) => {
  switch (type) {
    case "lecture":
      return "bg-primary text-primary-foreground"
    case "lab":
      return "bg-secondary text-secondary-foreground"
    case "tutorial":
      return "bg-muted text-muted-foreground"
    default:
      return "bg-muted text-muted-foreground"
  }
}

export function Timetable() {
  const today = new Date().toLocaleDateString("en-US", { weekday: "long" })

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Weekly Timetable</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {weekDays.map((day) => (
              <div key={day} className={`space-y-3 ${day === today ? "bg-muted/50 p-4 rounded-lg" : ""}`}>
                <div className="flex items-center space-x-2">
                  <h3 className="text-lg font-semibold text-foreground">{day}</h3>
                  {day === today && (
                    <Badge variant="secondary" className="bg-primary text-primary-foreground">
                      Today
                    </Badge>
                  )}
                </div>

                {mockSchedule[day] && mockSchedule[day].length > 0 ? (
                  <div className="grid gap-3">
                    {mockSchedule[day].map((classItem) => (
                      <Card key={classItem.id} className="border-l-4 border-l-primary">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="space-y-2">
                              <div className="flex items-center space-x-2">
                                <h4 className="font-semibold text-foreground">{classItem.subject}</h4>
                                <Badge className={getTypeColor(classItem.type)}>{classItem.type}</Badge>
                              </div>

                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <div className="flex items-center space-x-1">
                                  <Clock className="h-4 w-4" />
                                  <span>{classItem.time}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <MapPin className="h-4 w-4" />
                                  <span>{classItem.room}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <User className="h-4 w-4" />
                                  <span>{classItem.teacher}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No classes scheduled</p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
