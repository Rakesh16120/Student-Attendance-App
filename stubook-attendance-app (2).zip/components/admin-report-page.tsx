"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Filter } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts"

const performanceData = [
  { name: "Excellent (90-100)", count: 95 },
  { name: "Good (80-89)", count: 112 },
  { name: "Average (70-79)", count: 28 },
  { name: "Below Avg (60-69)", count: 5 },
]

const attendanceData = [
  { week: "Week 1", attendance: 94 },
  { week: "Week 2", attendance: 91 },
  { week: "Week 3", attendance: 93 },
  { week: "Week 4", attendance: 89 },
  { week: "Week 5", attendance: 92 },
]

export function ReportPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Reports & Analytics</h1>
          <p className="text-slate-400">Comprehensive academic and performance data</p>
        </div>
        <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
          <Download size={18} />
          Export Report
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Filter size={18} className="text-slate-400" />
              <span className="text-white">Filter by:</span>
            </div>
            <select className="bg-slate-700 border border-slate-600 text-white rounded-lg px-3 py-2">
              <option>All Classes</option>
              <option>1st Year</option>
              <option>2nd Year</option>
              <option>3rd Year</option>
            </select>
            <select className="bg-slate-700 border border-slate-600 text-white rounded-lg px-3 py-2">
              <option>All Semesters</option>
              <option>Sem 1</option>
              <option>Sem 2</option>
              <option>Sem 3</option>
            </select>
            <select className="bg-slate-700 border border-slate-600 text-white rounded-lg px-3 py-2">
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>This Semester</option>
              <option>This Year</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Performance Chart */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Performance Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} cursor={{ fill: "rgba(139, 92, 246, 0.1)" }} />
                <Bar dataKey="count" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Trend */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Attendance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={attendanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="week" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" domain={[0, 100]} />
                <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                <Legend />
                <Line type="monotone" dataKey="attendance" stroke="#8b5cf6" strokeWidth={2} dot={{ fill: "#8b5cf6" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Report Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Total Students</p>
            <p className="text-white text-3xl font-bold mt-2">240</p>
            <p className="text-slate-400 text-xs mt-2">Across all classes</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Avg Performance</p>
            <p className="text-white text-3xl font-bold mt-2">82.4%</p>
            <p className="text-green-400 text-xs mt-2">↑ 2% from last sem</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Avg Attendance</p>
            <p className="text-white text-3xl font-bold mt-2">92%</p>
            <p className="text-green-400 text-xs mt-2">↑ 5% from last sem</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <p className="text-slate-400 text-sm">Completion Rate</p>
            <p className="text-white text-3xl font-bold mt-2">98%</p>
            <p className="text-green-400 text-xs mt-2">↑ 1% from last sem</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
