"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChevronDown, ChevronUp, Download, Star } from "lucide-react"
import { QUESTION_PAPERS } from "@/lib/question-papers-data"

export function StudentQuestionPapers() {
  const [expandedPaper, setExpandedPaper] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredPapers = QUESTION_PAPERS.filter(
    (paper) =>
      paper.courseCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.courseName.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="flex gap-4">
        <Input
          placeholder="Search by course code or name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
      </div>

      {/* Papers List */}
      <div className="space-y-4">
        {filteredPapers.map((paper) => (
          <Card key={paper.id}>
            <CardHeader
              className="cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => setExpandedPaper(expandedPaper === paper.id ? null : paper.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-lg">{paper.courseCode}</CardTitle>
                    <Badge variant="outline">{paper.semester}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{paper.courseName}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Exam: {paper.examDate} | Duration: {paper.duration} | Max Marks: {paper.maxMarks}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                    }}
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                  {expandedPaper === paper.id ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </div>
              </div>
            </CardHeader>

            {expandedPaper === paper.id && (
              <CardContent className="space-y-6 border-t pt-6">
                {/* Part A */}
                <div>
                  <h3 className="font-semibold text-base mb-4 flex items-center gap-2">
                    Part A - {paper.partA.totalMarks} marks
                  </h3>
                  <div className="space-y-3">
                    {paper.partA.questions.map((q, idx) => (
                      <div key={idx} className="bg-muted/50 p-4 rounded-lg">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <p className="font-medium text-sm">
                              {idx + 1}. {q.question}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs whitespace-nowrap">
                              {q.marks} marks
                            </Badge>
                            <Badge variant="outline" className="text-xs whitespace-nowrap">
                              CO{q.co}
                            </Badge>
                          </div>
                        </div>
                        {q.isImportant && (
                          <div className="flex items-center gap-1 mt-2 text-yellow-600">
                            <Star className="h-4 w-4 fill-current" />
                            <span className="text-xs font-medium">Important Question</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Part B */}
                <div>
                  <h3 className="font-semibold text-base mb-4 flex items-center gap-2">
                    Part B - {paper.partB.totalMarks} marks
                  </h3>
                  <div className="space-y-3">
                    {paper.partB.questions.map((q, idx) => (
                      <div key={idx} className="bg-muted/50 p-4 rounded-lg">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <p className="font-medium text-sm">
                              {idx + 1}. {q.question}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs whitespace-nowrap">
                              {q.marks} marks
                            </Badge>
                            <Badge variant="outline" className="text-xs whitespace-nowrap">
                              CO{q.co}
                            </Badge>
                            <Badge variant="outline" className="text-xs whitespace-nowrap">
                              {q.btl}
                            </Badge>
                          </div>
                        </div>
                        {q.isImportant && (
                          <div className="flex items-center gap-1 mt-2 text-yellow-600">
                            <Star className="h-4 w-4 fill-current" />
                            <span className="text-xs font-medium">Important Question</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Important Questions Summary */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                    <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                    Important Questions for This Paper
                  </h3>
                  <ul className="space-y-2 text-sm">
                    {paper.importantQuestions.map((q, idx) => (
                      <li key={idx} className="text-foreground">
                        • {q}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {filteredPapers.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground">No question papers found matching your search.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
