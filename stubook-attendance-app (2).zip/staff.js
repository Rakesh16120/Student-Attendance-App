// Check if user is logged in
const currentUser = JSON.parse(localStorage.getItem("currentUser"))
if (!currentUser || currentUser.role !== "staff") {
  window.location.href = "1-login.html"
}

// Update user name
document.getElementById("userName").textContent = currentUser.name

// Set today's date
document.getElementById("date").valueAsDate = new Date()

// Sample student data
const students = [
  { id: "STU001", name: "K SAITEJA", rollNo: "21CS001" },
  { id: "STU002", name: "Priya Sharma", rollNo: "21CS002" },
  { id: "STU003", name: "Rahul Verma", rollNo: "21CS003" },
  { id: "STU004", name: "Anita Singh", rollNo: "21CS004" },
  { id: "STU005", name: "Vikram Kumar", rollNo: "21CS005" },
  { id: "STU006", name: "Sneha Patel", rollNo: "21CS006" },
  { id: "STU007", name: "Arjun Reddy", rollNo: "21CS007" },
  { id: "STU008", name: "Kavya Nair", rollNo: "21CS008" },
]

let attendanceData = {}

// Load students when class is selected
document.getElementById("class").addEventListener("change", function () {
  const selectedClass = this.value
  const subject = document.getElementById("subject").value

  if (selectedClass && subject) {
    loadStudents()
  }
})

document.getElementById("subject").addEventListener("change", function () {
  const selectedClass = document.getElementById("class").value
  const subject = this.value

  if (selectedClass && subject) {
    loadStudents()
  }
})

function loadStudents() {
  const studentList = document.getElementById("studentList")
  const submitBtn = document.getElementById("submitBtn")

  studentList.innerHTML = ""
  attendanceData = {}

  students.forEach((student) => {
    const studentItem = document.createElement("div")
    studentItem.className = "student-item"
    studentItem.innerHTML = `
            <div>
                <strong>${student.name}</strong><br>
                <small>Roll No: ${student.rollNo}</small>
            </div>
            <div class="attendance-controls">
                <button class="btn btn-present" onclick="markAttendance('${student.id}', 'present')">Present</button>
                <button class="btn btn-absent" onclick="markAttendance('${student.id}', 'absent')">Absent</button>
                <span class="status not-marked" id="status-${student.id}">Not Marked</span>
            </div>
        `
    studentList.appendChild(studentItem)
  })

  submitBtn.style.display = "block"
}

function markAttendance(studentId, status) {
  attendanceData[studentId] = status
  const statusElement = document.getElementById(`status-${studentId}`)

  statusElement.className = `status ${status}`
  statusElement.textContent = status === "present" ? "Present" : "Absent"
}

function submitAttendance() {
  const subject = document.getElementById("subject").value
  const selectedClass = document.getElementById("class").value
  const date = document.getElementById("date").value

  if (!subject || !selectedClass || !date) {
    alert("Please fill all fields")
    return
  }

  if (Object.keys(attendanceData).length === 0) {
    alert("Please mark attendance for at least one student")
    return
  }

  console.log("Attendance Data:", {
    subject,
    class: selectedClass,
    date,
    attendance: attendanceData,
  })

  const successMsg = document.getElementById("successMsg")
  successMsg.style.display = "block"

  setTimeout(() => {
    successMsg.style.display = "none"
    document.getElementById("studentList").innerHTML = ""
    document.getElementById("submitBtn").style.display = "none"
    attendanceData = {}
  }, 2000)
}

function logout() {
  localStorage.removeItem("currentUser")
  window.location.href = "1-login.html"
}
