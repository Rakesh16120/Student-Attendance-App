// Check if user is logged in
const currentUser = JSON.parse(localStorage.getItem("currentUser"))
if (!currentUser || currentUser.role !== "student") {
  window.location.href = "1-login.html"
}

// Update user name
document.getElementById("userName").textContent = currentUser.name

function logout() {
  localStorage.removeItem("currentUser")
  window.location.href = "1-login.html"
}
