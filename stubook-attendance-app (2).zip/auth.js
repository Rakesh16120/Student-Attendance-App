const users = {
  STU001: { password: "saiteja12", role: "student", name: "K SAITEJA" },
  STAFF001: { password: "rakesh12", role: "staff", name: "K Swarnalakshmi" },
  ADMIN001: { password: "password123", role: "admin", name: "Admin User" },
}

document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault()

  const userType = document.getElementById("userType").value
  const username = document.getElementById("username").value.toUpperCase()
  const password = document.getElementById("password").value
  const errorMsg = document.getElementById("errorMsg")

  if (users[username] && users[username].password === password && users[username].role === userType) {
    localStorage.setItem(
      "currentUser",
      JSON.stringify({
        username: username,
        name: users[username].name,
        role: users[username].role,
      }),
    )

    if (userType === "student") {
      window.location.href = "2-student-dashboard.html"
    } else if (userType === "staff") {
      window.location.href = "3-staff-dashboard.html"
    } else {
      alert("Admin dashboard coming soon!")
    }
  } else {
    errorMsg.style.display = "block"
  }
})
