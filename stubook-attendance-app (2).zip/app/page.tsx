"use client"

import { useState } from "react"
import { SplashScreen } from "@/components/splash-screen"
import { LoginForm } from "@/components/login-form"

export default function Home() {
  const [showSplash, setShowSplash] = useState(true)

  const handleSplashComplete = () => {
    setShowSplash(false)
  }

  return (
    <main className="min-h-screen">
      {showSplash ? <SplashScreen onComplete={handleSplashComplete} /> : <LoginForm />}
    </main>
  )
}
