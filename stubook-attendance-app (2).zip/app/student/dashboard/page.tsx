"use client"

import { AuthGuard } from "@/components/auth-guard"
import { StudentDashboard } from "@/components/student-dashboard"

export default function StudentDashboardPage() {
  return (
    <AuthGuard requiredUserType="student">
      <StudentDashboard />
    </AuthGuard>
  )
}
