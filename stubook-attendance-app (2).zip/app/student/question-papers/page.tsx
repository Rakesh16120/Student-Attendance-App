"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { QUESTION_PAPERS, IMPORTANT_QUESTIONS_BY_COURSE } from "@/lib/question-papers-data"
import { Download, BookOpen, Lightbulb, ChevronDown, ChevronUp } from "lucide-react"

export default function QuestionPapersPage() {
  const [selectedPaper, setSelectedPaper] = useState(QUESTION_PAPERS[0])
  const [expandedSections, setExpandedSections] = useState<string[]>(["partA"])
  const [searchQuery, setSearchQuery] = useState("")

  const toggleSection = (section: string) => {
    setExpandedSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    )
  }

  const filteredPapers = QUESTION_PAPERS.filter(
    (paper) =>
      paper.courseName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.courseCode.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className="w-8 h-8 text-purple-500" />
            <h1 className="text-4xl font-bold text-white">Question Papers</h1>
          </div>
          <p className="text-slate-400">Access previous exam papers and important questions</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Papers List */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Courses</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Input
                  placeholder="Search papers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 mb-4"
                />
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredPapers.map((paper) => (
                    <button
                      key={paper.id}
                      onClick={() => {
                        setSelectedPaper(paper)
                        setExpandedSections(["partA"])
                      }}
                      className={`w-full text-left p-3 rounded-lg transition-colors ${
                        selectedPaper.id === paper.id
                          ? "bg-purple-600 text-white"
                          : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                      }`}
                    >
                      <div className="font-semibold text-sm">{paper.courseCode}</div>
                      <div className="text-xs mt-1 opacity-80">{paper.courseName}</div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Paper Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Paper Header */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-2xl">{selectedPaper.courseName}</CardTitle>
                    <CardDescription className="text-slate-400 mt-2">
                      {selectedPaper.courseCode} • {selectedPaper.department}
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    className="border-purple-500 text-purple-400 hover:bg-purple-600 hover:text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="grid grid-cols-4 gap-4 pt-4 border-t border-slate-700">
                <div>
                  <p className="text-slate-400 text-sm">Exam Date</p>
                  <p className="text-white font-semibold">{selectedPaper.examDate}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Duration</p>
                  <p className="text-white font-semibold">{selectedPaper.duration}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Max Marks</p>
                  <p className="text-white font-semibold">{selectedPaper.maxMarks}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Semester</p>
                  <p className="text-white font-semibold">Sem {selectedPaper.semester}</p>
                </div>
              </CardContent>
            </Card>

            {/* Part A Questions */}
            {selectedPaper.partA.questions.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader
                  className="cursor-pointer hover:bg-slate-700 transition-colors"
                  onClick={() => toggleSection("partA")}
                >
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <span>PART A - Short Answer Questions ({selectedPaper.partA.totalMarks} marks)</span>
                    </CardTitle>
                    {expandedSections.includes("partA") ? (
                      <ChevronUp className="w-5 h-5 text-purple-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-purple-500" />
                    )}
                  </div>
                </CardHeader>
                {expandedSections.includes("partA") && (
                  <CardContent className="space-y-4 pt-4 border-t border-slate-700">
                    {selectedPaper.partA.questions.map((q, idx) => (
                      <div key={idx} className="border-l-2 border-purple-500 pl-4 py-2">
                        <p className="text-white font-semibold">Q{idx + 1}: {q.question}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm">
                          <span className="text-slate-400">Marks: {q.marks}</span>
                          <span className="text-purple-400">CO {q.co}</span>
                          {q.btl && <span className="text-blue-400">{q.btl}</span>}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                )}
              </Card>
            )}

            {/* Part B Questions */}
            {selectedPaper.partB.questions.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader
                  className="cursor-pointer hover:bg-slate-700 transition-colors"
                  onClick={() => toggleSection("partB")}
                >
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <span>PART B - Choice Questions ({selectedPaper.partB.totalMarks} marks)</span>
                    </CardTitle>
                    {expandedSections.includes("partB") ? (
                      <ChevronUp className="w-5 h-5 text-purple-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-purple-500" />
                    )}
                  </div>
                </CardHeader>
                {expandedSections.includes("partB") && (
                  <CardContent className="space-y-4 pt-4 border-t border-slate-700">
                    {selectedPaper.partB.questions.map((q, idx) => (
                      <div key={idx} className="border-l-2 border-blue-500 pl-4 py-2">
                        <p className="text-white font-semibold">Q{idx + 1}: {q.question}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm">
                          <span className="text-slate-400">Marks: {q.marks}</span>
                          <span className="text-purple-400">CO {q.co}</span>
                          {q.btl && <span className="text-blue-400">{q.btl}</span>}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                )}
              </Card>
            )}

            {/* Important Questions */}
            <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  Important Questions for {selectedPaper.courseCode}
                </CardTitle>
                <CardDescription className="text-slate-300">
                  Focus on these key topics for better exam preparation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(IMPORTANT_QUESTIONS_BY_COURSE[selectedPaper.courseCode] || []).map(
                    (question, idx) => (
                      <li key={idx} className="flex items-start gap-3 text-slate-100">
                        <span className="text-yellow-400 font-bold mt-0.5">★</span>
                        <span>{question}</span>
                      </li>
                    )
                  )}
                </ul>
              </CardContent>
            </Card>

            {/* Study Tips */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Study Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-slate-300">
                <p>✓ Practice previous year papers to understand exam pattern and question types</p>
                <p>✓ Focus on important questions highlighted with the star (★) icon</p>
                <p>✓ Allocate time based on marks distribution - Part A (20), Part B (30), Part C (50)</p>
                <p>✓ Read course outcomes (CO) and Bloom's Taxonomy Levels (BTL) for each question</p>
                <p>✓ Write model answers for Part B and Part C questions for better preparation</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
