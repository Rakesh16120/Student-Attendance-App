import { openai } from "@ai-sdk/openai"
import { convertToModelMessages, streamText, type UIMessage } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const systemPrompt = `You are Stubook AI, a helpful assistant for students at Hindustan University. You can help with:

1. Academic questions about subjects like Data Structures, Algorithms, Database Management, Web Development, Software Engineering, and Mobile App Development
2. University policies and procedures
3. Study tips and academic guidance
4. General questions about student life
5. Attendance and timetable related queries

Keep your responses helpful, concise, and student-friendly. If you don't know something specific about the university, be honest about it and suggest they contact the administration.`

  const prompt = [{ role: "system" as const, content: systemPrompt }, ...convertToModelMessages(messages)]

  const result = streamText({
    model: openai("gpt-4o-mini"),
    messages: prompt,
    maxTokens: 1000,
    temperature: 0.7,
  })

  return result.toDataStreamResponse()
}
