"use client"

import { AuthGuard } from "@/components/auth-guard"
import { StaffDashboard } from "@/components/staff-dashboard"

export default function StaffDashboardPage() {
  return (
    <AuthGuard requiredUserType="staff">
      <StaffDashboard />
    </AuthGuard>
  )
}
